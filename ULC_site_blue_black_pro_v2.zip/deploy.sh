#!/usr/bin/env bash
set -euo pipefail
REPO=${1:-git@github.com:GroupeULC/Groupe-ULC.git}
BRANCH=${2:-main}
echo "Pousser vers $REPO ($BRANCH)"
git init
git checkout -B "$BRANCH"
git add .
git commit -m "feat(site): v2 bleu/noir pro — titre simplifié, demande rapide épurée, couverture CA–US–International, email logistics@groupeulc.com"
git remote add origin "$REPO" || git remote set-url origin "$REPO"
git push -u origin "$BRANCH" --force
echo "✅ Poussé. Activez GitHub Pages (Settings → Pages → GitHub Actions)."
