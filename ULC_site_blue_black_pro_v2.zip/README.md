# Groupe ULC — Site (Blue/Black Pro, v2)
- Titre simplifié (pas de mention de couleurs)
- Demande rapide épurée (email requis)
- Couverture Canada · US · International
- Email: logistics@groupeulc.com

## Déploiement GitHub Pages
1) Créez un repo public (ex: Groupe-ULC) et poussez ces fichiers à la racine.
2) Settings → Pages → Source = GitHub Actions.
3) Le workflow `.github/workflows/pages.yml` déploie automatiquement.

## Brancher l'API
Ajoutez avant `assets/js/main.js` (dans `suivi.html` et si besoin ailleurs):
```html
<script>window.ULC_API_BASE = "https://votre-api.exemple.com";</script>
```
