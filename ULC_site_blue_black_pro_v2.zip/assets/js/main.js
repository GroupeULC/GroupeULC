// Site logic (v2) with simplified quick request and logistics@groupeulc.com
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.menu');
  if (navToggle && menu) {
    navToggle.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(open));
    });
  }
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // quote form -> mailto logistics@groupeulc.com
  const quote = document.getElementById('quoteForm');
  if (quote) {
    quote.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(quote);
      const name = encodeURIComponent(fd.get('name')||'');
      const email= encodeURIComponent(fd.get('email')||'');
      const msg  = encodeURIComponent(fd.get('msg')||'');
      const u = `mailto:logistics@groupeulc.com?subject=Soumission%20(${name||'client'})&body=${msg}%0A%0ADe:%20${name}%20<${email}>`;
      window.location.href = u;
      const st = document.getElementById('quoteState'); if (st) st.textContent = 'Merci! Votre courriel s’ouvre.';
    });
  }

  // contact form -> mailto logistics@groupeulc.com
  const contact = document.getElementById('contactForm');
  if (contact) {
    contact.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(contact);
      const name = encodeURIComponent(fd.get('name')||'');
      const email= encodeURIComponent(fd.get('email')||'');
      const msg  = encodeURIComponent(fd.get('msg')||'');
      const u = `mailto:logistics@groupeulc.com?subject=Contact%20(${name||'client'})&body=${msg}%0A%0ADe:%20${name}%20<${email}>`;
      window.location.href = u;
      const st = document.getElementById('contactState'); if (st) st.textContent = 'Merci! Votre courriel s’ouvre.';
    });
  }

  // Transporteurs page
  const loadBtn = document.getElementById('loadCarriers');
  if (loadBtn) {
    loadBtn.addEventListener('click', async () => {
      const tbody = document.querySelector('#carriersTable tbody');
      const filter = (document.getElementById('filterCarrier')||{}).value || '';
      const API_BASE = window.ULC_API_BASE || ''; // set in production
      const url = API_BASE ? `${API_BASE}/api/carriers` : '';
      try {
        let data;
        if (url) {
          const r = await fetch(url, { headers: { 'X-API-Key': localStorage.getItem('ULC_API_KEY') || 'demo123' } });
          data = await r.json();
        } else {
          // demo data
          data = [
            {name:'Transporteur Nord', phone:'+1 514 000 0000', email:'ops@nord.com', hours:'8h–17h ET', modes:'LTL, FTL', service_areas:'QC, ON, US'},
            {name:'Logis Express', phone:'+1 416 000 0000', email:'dispatch@logisx.com', hours:'24/7', modes:'Express, LTL', service_areas:'QC, ON, NY, International'}
          ];
        }
        if (tbody) {
          tbody.innerHTML = '';
          data.filter(c => !filter || (c.name||'').toLowerCase().includes(filter.toLowerCase()))
              .forEach(c => {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td>${c.name||''}</td><td>${c.phone||''}</td><td>${c.email||''}</td><td>${c.hours||''}</td><td>${c.modes||''}</td><td>${c.service_areas||''}</td>`;
                tbody.appendChild(tr);
              });
        }
      } catch (e) {
        console.error(e);
      }
    });
  }

  // Suivi (page suivi.html) + Home demo
  const tForm = document.getElementById('trackingForm');
  const tInput = document.getElementById('trackingInput');
  const tStop = document.getElementById('trackingStop');
  const tMeta = document.getElementById('trackingMeta');
  const tStatus = document.getElementById('trackingStatus');
  const tTimeline = document.getElementById('trackingTimeline');

  let ws=null, es=null, poller=null;
  const API_BASE = window.ULC_API_BASE || ''; // set to your API base for production
  const TRACKING_BASE = API_BASE ? (API_BASE + '/api/shipments') : '';
  const SSE_URL       = API_BASE ? (API_BASE + '/api/track/stream') : '';
  const WS_URL        = API_BASE ? (API_BASE.replace('http','ws') + '/ws/track') : '';
  const API_KEY       = localStorage.getItem('ULC_API_KEY') || 'demo123';

  function setStatus(text){
    if (!tStatus) return;
    tStatus.textContent = text || '';
    tStatus.className = 'pill';
  }
  function renderTimeline(events){
    if (!tTimeline) return;
    tTimeline.innerHTML = '';
    (events||[]).forEach(e=>{
      const li = document.createElement('li');
      const when = new Date(e.time||Date.now()).toLocaleString('fr-CA');
      li.textContent = `${when} — ${e.label}`;
      tTimeline.appendChild(li);
    });
  }
  function updateView(p){
    if (!p) return;
    if (tMeta && p.meta) tMeta.textContent = `${p.meta.carrier||'—'} · ${p.meta.origin||''} → ${p.meta.destination||''}`;
    if (p.status) setStatus(p.status.text);
    if (p.events) renderTimeline(p.events);
  }
  function stopAll(){
    if (ws){ws.close();ws=null;}
    if (es){es.close();es=null;}
    if (poller){clearInterval(poller);poller=null;}
  }
  if (tStop) tStop.addEventListener('click', stopAll);

  if (tForm){
    tForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const id = (tInput && tInput.value.trim()) || 'ULC-123456';
      stopAll();
      if (!API_BASE){
        tMeta && (tMeta.textContent = `Démo · ${id}`);
        const demo=['Dossier créé','Ramassage confirmé','En route vers le hub','Inspection douanière','Dédouané','En livraison','Livré (POD)'];
        let i=0, ev=[];
        const tick=()=>{
          const now=new Date(Date.now()+i*25*60000).toISOString();
          const label=demo[Math.min(i,demo.length-1)];
          updateView({meta:{carrier:'ULC',origin:'CA',destination:'US'},status:{text:label},events:ev.concat([{time:now,label}])});
          ev.push({time:now,label}); i++; if(i>=demo.length){clearInterval(poller);poller=null;}
        };
        tick(); poller=setInterval(tick, 1200);
        return;
      }
      // Else WS -> SSE -> Poll
      if (WS_URL){
        try{
          ws = new WebSocket(`${WS_URL}?tracking=${encodeURIComponent(id)}&key=${encodeURIComponent(API_KEY)}`);
          ws.onopen = ()=> tMeta && (tMeta.textContent = `WebSocket · ${id}`);
          ws.onmessage = ev => { try{ updateView(JSON.parse(ev.data)); }catch{} };
          ws.onerror=()=> setStatus('WS error');
          return;
        }catch(e){}
      }
      if (SSE_URL){
        try{
          es = new EventSource(`${SSE_URL}?tracking=${encodeURIComponent(id)}`);
          tMeta && (tMeta.textContent = `SSE · ${id}`);
          es.onmessage = ev => { try{ updateView(JSON.parse(ev.data)); }catch{} };
          es.onerror=()=> setStatus('SSE error');
          return;
        }catch(e){}
      }
      if (TRACKING_BASE){
        tMeta && (tMeta.textContent = `Polling · ${id}`);
        const once = async ()=>{
          try{
            const r = await fetch(`${TRACKING_BASE}/${encodeURIComponent(id)}`, { headers: {'X-API-Key': API_KEY} });
            if (r.ok) updateView(await r.json());
          }catch(e){}
        };
        once(); poller = setInterval(once, 10000);
      }
    });
  }
});

function demoTrackHome(e){
  e.preventDefault();
  const id = (document.getElementById('homeTrackId').value||'ULC-123456').trim();
  const t = document.getElementById('homeTimeline');
  const s = document.getElementById('homeStatus');
  t.innerHTML=''; s.textContent='';
  const steps=['Dossier créé','Ramassage confirmé','En route vers le hub','Inspection douanière','Dédouané','En livraison','Livré (POD)'];
  let i=0;
  const add=()=>{
    const li=document.createElement('li');
    li.textContent=new Date().toLocaleString('fr-CA')+' — '+steps[i];
    t.appendChild(li);
    s.textContent=steps[i];
    i++; if(i>=steps.length) clearInterval(timer);
  };
  add();
  const timer=setInterval(add,1100);
  return false;
}
